<?php
session_start();
$_SESSION["tab"] = "New Receive";

if ($_SESSION["login"] != 1) {
    echo '<h2 txtcolor="red">Authentication Error!!!</h2>';
} else {
    include_once('header.php');
    include_once('connection.php'); // Ensure the connection is included

    $pid = $_POST['pid'];
    $units = $_POST['units'];
    $hospital = $_POST['hospital']; // Ensure hospital is captured correctly

    date_default_timezone_set("Asia/Kolkata"); 
    $date = date('Y-m-d');
    $time = date('H:i:s');

    // Check if sufficient stock is available
    $sql_stock_check = "SELECT s_quantity FROM Stock WHERE s_blood_group = (SELECT p_blood_group FROM Person WHERE p_id = ?)";
    $stmt_stock = $con->prepare($sql_stock_check);
    $stmt_stock->bind_param('i', $pid);
    $stmt_stock->execute();
    $stmt_stock->bind_result($stock_quantity);
    $stmt_stock->fetch();
    $stmt_stock->close();

    if ($stock_quantity >= $units) {
        // Insert into the Receive table
        $sql_insert_receive = "INSERT INTO Receive (p_id, r_date, r_time, r_quantity, r_hospital) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert_receive = $con->prepare($sql_insert_receive);
        $stmt_insert_receive->bind_param('issis', $pid, $date, $time, $units, $hospital);

        // Update the Stock table
        $sql_update_stock = "UPDATE Stock SET s_quantity = s_quantity - ? WHERE s_blood_group = (SELECT p_blood_group FROM Person WHERE p_id = ?)";
        $stmt_update_stock = $con->prepare($sql_update_stock);
        $stmt_update_stock->bind_param('ii', $units, $pid);

        if ($stmt_insert_receive->execute() && $stmt_update_stock->execute()) {
            echo 'Your receiving is successful';
        } else {
            echo "Error: " . $stmt_insert_receive->error . "<br>" . $stmt_update_stock->error;
        }

        $stmt_insert_receive->close();
        $stmt_update_stock->close();
    } else {
        echo "No sufficient stock available";
    }

    include_once('footer.php');
}
?>
