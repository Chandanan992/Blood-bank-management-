<?php 
if (isset($con) && $con instanceof mysqli && $con->ping()) {
    $con->close();
}
echo "</div></div></body></html>";
?>
