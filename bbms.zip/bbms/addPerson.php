<?php
session_start();
$_SESSION["tab"] = "Add Person";

if ($_SESSION["login"] != 1) {
    echo '<h2 txtcolor="red">Authentication Error!!!</h2>';
} else {
    include_once('header.php');
    include_once('connection.php'); // Ensure the connection is included

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $blood_group = $_POST['blood_group'];
    $address = $_POST['address'];
    $med_issues = $_POST['med_issues'];

    // Use prepared statement to call the stored procedure
    $sql = "CALL AddPersonProcedure(?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('sssssss', $name, $phone, $gender, $dob, $blood_group, $address, $med_issues);
    $stmt->execute();

    // Fetch the result set
    $result = $stmt->get_result();
    if ($result) {
        $row = $result->fetch_assoc();
        $pid = $row['p_id'];

        echo '<h2>' . $name . '</h2><br><br>';
        echo 'Your registration is successful..<br><br>';
        echo 'Personal Id: ' . $pid . '<br><br>';
        echo 'Name: ' . $name . '<br><br>';
        echo 'Phone Number: ' . $phone . '<br><br>';
        echo 'DOB: ' . $dob . '<br><br>';
        echo 'Blood Group: ' . $blood_group . '<br><br>';
        echo 'Gender: ';
        if ($gender === 'm')
            echo 'Male<br><br>';
        if ($gender === 'f')
            echo 'Female<br><br>';
        if ($gender === 'o')
            echo 'Others<br><br>';
        echo 'Address: ' . $address . '<br><br>';

        echo 'Medical Issues: ';
        if ($med_issues === "")
            echo 'None<br><br>';
        else {
            echo $med_issues . '<br><br>';
        }
        echo '<div style ="color:red;">NB: Please keep your Personal Id for future reference!!!</div>';
    } else {
        echo "Error: " . $stmt->error . "<br>";
    }

    // Free result set and close the statement
    $result->free_result();
    $stmt->close();

    include_once('footer.php');
}
?>
